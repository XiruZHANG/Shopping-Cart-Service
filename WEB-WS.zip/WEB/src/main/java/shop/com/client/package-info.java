@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.com.shop")
package shop.com.client;
