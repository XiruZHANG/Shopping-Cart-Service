package com.shoppingcart.client;

import java.util.List;

import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.shoppingcart.dao.ShoppingCartDAO;
import com.shoppingcart.model.Product;

public class ShoppingCartClient {

    private static final String BASE_URI = "http://localhost:8080/shopping-cart";

    private Client client;
    private WebTarget target;
    private ShoppingCartDAO dao;

    public ShoppingCartClient() {
        client = ClientBuilder.newClient();
        target = client.target(BASE_URI);
        dao = new ShoppingCartDAO();
    }

    public double getProductPrice(int productId) {
        Response response = target.path("cart").path("product").path(String.valueOf(productId))
                .request(MediaType.APPLICATION_JSON)
                .get();

        if (response.getStatus() == Response.Status.OK.getStatusCode()) {
        	String result = response.readEntity(String.class);
            JsonObject json = (JsonObject) (Json.createArrayBuilder());
            double myPrice = json.getJsonNumber("myPrice").doubleValue();
            double competitorPrice = json.getJsonNumber("competitorPrice").doubleValue();

            // 根据业务逻辑计算价格
            double finalPrice = calculatePrice(myPrice, competitorPrice);

            return finalPrice;
        } else {
            return -1.0;
        }
    }

    private double calculatePrice(double myPrice, double competitorPrice) {
        double priceDifference = competitorPrice - myPrice;
        return priceDifference;
    }


	public boolean addToCart(int userId, Product product) {
        Response response = target.path("cart").path("user").path(String.valueOf(userId)).path("cart")
                .request(MediaType.APPLICATION_JSON)
                .post(Entity.entity(product, MediaType.APPLICATION_JSON));

        return response.getStatus() == Response.Status.OK.getStatusCode();
    }

    public void close() {
        client.close();
    }

    private double getCompetitorPrice(int productId) {
        // Create a client for the external service
        Client client = ClientBuilder.newClient();

        // Set the target of the client to the external service endpoint
        WebTarget target = client.target("https://example.com/products/" + productId);

        // Make a GET request to the external service endpoint
        Response response = target.request().get();

        // Read the response body as a JSON object
        JsonObject product = response.readEntity(JsonObject.class);

        // Extract the price from the JSON object and convert it to a double
        double price = product.getJsonNumber("price").doubleValue();

        // Close the client and the response
        response.close();
        client.close();

        // Return the price
        return price;
    }

}