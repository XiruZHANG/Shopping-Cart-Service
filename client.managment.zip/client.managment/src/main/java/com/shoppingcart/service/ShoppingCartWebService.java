package com.shoppingcart.service;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.shoppingcart.model.Product;
import com.shoppingcart.model.User;

@WebService
@Path("/shoppingcart")
public class ShoppingCartWebService {

    // 获取用户信息的方法，使用 JAX-WS 注解
    @WebMethod
    @GET
    @Path("/user/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    public User getUserById(@PathParam("userId") int userId) {
        // 实现逻辑，根据用户 ID 从数据库或其他数据源中获取用户信息
        User user = new User(userId, null);
        return user;
    }

    // 获取商品信息的方法，使用 JAX-RS 注解
    @GET
    @Path("/product/{productId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Product getProductById(@PathParam("productId") int productId) {
        // 实现逻辑，根据商品 ID 从数据库或其他数据源中获取商品信息
        Product product = new Product(productId, "Shirt", 20.0);
        return product;
    }

    // 添加商品到购物车的方法，使用 JAX-RS 注解
    @POST
    @Path("/cart")
    @Consumes(MediaType.APPLICATION_JSON)
    public void addProductToCart(Product product) {
        // 实现逻辑，将商品添加到购物车中
        System.out.println("Product " + product.getName() + " has been added to cart.");
    }

    // 从购物车中删除商品的方法，使用 JAX-RS 注解
    @DELETE
    @Path("/cart/{productId}")
    public void removeProductFromCart(@PathParam("productId") int productId) {
        // 实现逻辑，将指定 ID 的商品从购物车中删除
        System.out.println("Product " + productId + " has been removed from cart.");
    }

    // 下订单的方法，使用 JAX-RS 注解
    @POST
    @Path("/order")
    @Consumes(MediaType.APPLICATION_JSON)
    public void placeOrder(List<Product> products) {
        // 实现逻辑，生成订单并保存到数据库或其他数据源中
        System.out.println("Order has been placed with products: " + products.toString());
    }
}

