package com.shoppingcart.dao;
import java.sql.*;

import com.shoppingcart.model.Product;

public class ShoppingCartDAO {

    String url = "jdbc:mysql://mysql-qichen.alwaysdata.net:3306/qichen_webprojet";
    String user = "qichen";
    String password = "shaoqichen12345";


    public double getProductPrice(int productId) {
        double price = 0.0;

        try {
            Connection conn = DriverManager.getConnection(url, user, password);
            PreparedStatement stmt = conn.prepareStatement("SELECT price FROM products WHERE id = ?");
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                price = rs.getDouble("price");
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return price;
    }

    public boolean addProductToCart(int userId, Product product) {
        boolean success = false;

        try {
            Connection conn = DriverManager.getConnection(url, user, password);
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO carts (user_id, product_id, product_name, product_price) VALUES (?, ?, ?, ?)");
            stmt.setInt(1, userId);
            stmt.setInt(2, product.getId());
            stmt.setString(3, product.getName());
            stmt.setDouble(4, product.getPrice());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                success = true;
            }
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return success;
    }
}
